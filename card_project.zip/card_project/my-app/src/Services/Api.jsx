import axios from "axios";
const api = axios.create({
  baseURL: "http://localhost:3001",
});

export const getCards = () => api.get("/cards");
export const deleteCard = (id) => api.delete(`/cards/${id}`);
export const addCard = (data) => api.post("/cards", data);

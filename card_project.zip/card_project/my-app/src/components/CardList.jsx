import { useEffect, useState } from "react";
import { getCards, deleteCard, addCard } from "../Services/Api";

import CardItem from "./CardItem";
import { AnimatePresence } from "framer-motion";

export default function CardList() {
  const [cards, setCards] = useState([]);

  useEffect(() => {
    fetchCards();
  }, []);

  const fetchCards = async () => {
    try {
      const res = await getCards();
      setCards(res.data);
    } catch (error) {
      console.error("Failed to fetch cards:", error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await deleteCard(id);
      setCards((prev) => prev.filter((card) => card.id !== id));
    } catch (error) {
      console.error("Failed to delete card:", error);
    }
  };

  const handleAdd = async () => {
    try {
      const newCard = { title: `Card ${Date.now()}` };
      const res = await addCard(newCard);
      setCards((prev) => [...prev, res.data]);
    } catch (error) {
      console.error("Failed to add card:", error);
    }
  };

  return (
    <>
      <button className='add-btn' onClick={handleAdd}>
        + Add Card
      </button>
      <div className='card-container'>
        <AnimatePresence>
          {cards.map((card) => (
            <CardItem key={card.id} card={card} onDelete={handleDelete} />
          ))}
        </AnimatePresence>
      </div>
    </>
  );
}

import { motion } from "framer-motion";
import { FaTrash } from "react-icons/fa";

export default function CardItem({ card, onDelete }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0 }}
      className='card'
    >
      <h3>{card.title}</h3>
      <button onClick={() => onDelete(card.id)}>
        <FaTrash />
      </button>
    </motion.div>
  );
}

import CardList from "./components/CardList";
import "./App.css";

export default function App() {
  return (
    <div className='App'>
      <h1>Card Manager</h1>
      <CardList />
    </div>
  );
}
